# RPGQuests — RPG DEFINITIVO 2.3.2

Mod fuente para **Minecraft 1.20.1 / Forge 47.3.22 / Java 17**.

## Tipos de misiones de esta versión

- **Recolección:** requiere tener los objetos en el inventario; al reclamar, los consume.
- **Fabricación:** consulta la estadística de objetos fabricados por el jugador.
- **Combate:** consulta la estadística de enemigos derrotados, incluidos tipos de entidad de mods.
- **Minería:** consulta la estadística de bloques picados.
- **Exploración de dimensiones:** se reclama estando en la dimensión indicada (Nether o End).

Incluye 36 misiones con cadenas y recompensas de experiencia y esmeraldas, usando IDs de objetos/bloques/entidades encontrados en los JAR personalizados incluidos en la exportación.

## Compilar e instalar

Este ZIP contiene el **código fuente**, no un JAR compilado. No lo copies directamente a `mods`.

1. Instala Java 17 y abre esta carpeta como proyecto Gradle en IntelliJ IDEA.
2. Ejecuta la tarea `build`.
3. Copia `build/libs/rpgquests-1.1.0.jar` a la carpeta `mods` del perfil CurseForge.
4. Inicia el perfil y pulsa **J** para abrir el diario.

## Notas importantes

- No se ha podido compilar ni probar dentro de Minecraft en este entorno. Haz copia de seguridad de tu mundo antes de probarlo.
- Las misiones de fabricación, combate y minería usan estadísticas de Minecraft. La progresión cuenta las acciones históricas de la estadística correspondiente, así que si ya fabricaste ese objeto o derrotaste ese enemigo antes de aceptar la misión, podría contar desde el inicio.
- Las misiones de dimensión se reclaman mientras estás dentro de la dimensión objetivo.
- Los JAR personalizados incluidos en la exportación tienen algunos duplicados/versiones paralelas. Revisa el perfil antes de iniciar el juego; las IDs repetidas de mods pueden provocar conflictos independientes de este mod.
- No se han añadido aún objetivos específicos de estructura, conversación con NPC, domesticación/cría ni jefes de mods que requieran detección especial. Se pueden incorporar en una siguiente versión con eventos y progreso sincronizado.
