package es.buneez.rpgquests;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.function.Supplier;

public class ClaimQuestPacket {
    private final String questId;

    public ClaimQuestPacket(String questId) {
        this.questId = questId;
    }

    public static void encode(ClaimQuestPacket msg, FriendlyByteBuf buf) {
        buf.writeUtf(msg.questId, 64);
    }

    public static ClaimQuestPacket decode(FriendlyByteBuf buf) {
        return new ClaimQuestPacket(buf.readUtf(64));
    }

    public static void handle(ClaimQuestPacket msg, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context ctx = supplier.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player == null) return;
            Quest quest = QuestCatalog.ALL.stream().filter(q -> q.id().equals(msg.questId)).findFirst().orElse(null);
            if (quest == null) return;

            if (QuestCatalog.isClaimed(player, quest.id())) {
                player.sendSystemMessage(Component.literal("§eYa has reclamado esta misión."));
                return;
            }
            if (!QuestCatalog.prerequisiteMet(player, quest)) {
                player.sendSystemMessage(Component.literal("§cPrimero debes completar la misión anterior de esta cadena."));
                return;
            }
            if (!QuestCatalog.targetExists(quest)) {
                player.sendSystemMessage(Component.literal("§cNo se encuentra el objetivo de esta misión. Comprueba la versión del mod correspondiente."));
                return;
            }
            if (QuestCatalog.progress(player, quest) < quest.amount()) {
                player.sendSystemMessage(Component.literal("§cTodavía no has completado el objetivo."));
                return;
            }
            if (quest.type() == Quest.Type.COLLECT && !QuestCatalog.consume(player, quest)) return;

            var data = player.getPersistentData();
            var questData = data.getCompound("rpgquests");
            questData.putBoolean(quest.id(), true);
            data.put("rpgquests", questData);

            player.giveExperiencePoints(quest.xpReward());
            if (quest.emeraldReward() > 0) {
                player.getInventory().placeItemBackInInventory(new ItemStack(Items.EMERALD, quest.emeraldReward()));
            }
            player.sendSystemMessage(Component.literal("§a¡Misión completada: §f" + quest.title() + "§a! +" + quest.xpReward() + " XP y " + quest.emeraldReward() + " esmeraldas."));
            var updated = player.getPersistentData().getCompound("rpgquests");
            java.util.List<String> claimed = new java.util.ArrayList<>();
            for (Quest q : QuestCatalog.ALL) if (updated.getBoolean(q.id())) claimed.add(q.id());
            QuestNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new SyncQuestStatePacket(claimed));
        });
        ctx.setPacketHandled(true);
    }
}
