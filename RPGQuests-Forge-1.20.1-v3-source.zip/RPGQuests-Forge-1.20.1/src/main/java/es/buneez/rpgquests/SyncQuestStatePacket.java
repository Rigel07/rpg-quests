package es.buneez.rpgquests;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class SyncQuestStatePacket {
    private final List<String> claimed;

    public SyncQuestStatePacket(List<String> claimed) {
        this.claimed = List.copyOf(claimed);
    }

    public static void encode(SyncQuestStatePacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.claimed.size());
        for (String id : msg.claimed) buf.writeUtf(id, 64);
    }

    public static SyncQuestStatePacket decode(FriendlyByteBuf buf) {
        int size = Math.min(buf.readVarInt(), 256);
        List<String> ids = new ArrayList<>();
        for (int i = 0; i < size; i++) ids.add(buf.readUtf(64));
        return new SyncQuestStatePacket(ids);
    }

    public static void handle(SyncQuestStatePacket msg, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context ctx = supplier.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientQuestState.apply(msg.claimed)));
        ctx.setPacketHandled(true);
    }
}
