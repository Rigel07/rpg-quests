package es.buneez.rpgquests;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.stats.Stat;
import net.minecraft.world.entity.player.Player;

/** Acceso a las estadisticas del jugador local. Solo se llama desde el cliente (nunca carga en un servidor). */
final class ClientStats {
    private ClientStats() {}

    static int value(Player player, Stat<?> stat) {
        return player instanceof LocalPlayer local ? local.getStats().getValue(stat) : 0;
    }
}
