package es.buneez.rpgquests;

import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

@Mod.EventBusSubscriber(modid = RPGQuests.MODID, value = Dist.CLIENT)
public final class ClientQuestState {
    private ClientQuestState() {}

    public static void apply(List<String> claimed) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        var data = mc.player.getPersistentData();
        var state = data.getCompound("rpgquests");
        for (Quest quest : QuestCatalog.ALL) state.putBoolean(quest.id(), claimed.contains(quest.id()));
        data.put("rpgquests", state);
        if (mc.screen instanceof QuestBookScreen screen) screen.refresh();
    }
}
