package es.buneez.rpgquests;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class RequestQuestStatePacket {
    public static void encode(RequestQuestStatePacket msg, FriendlyByteBuf buf) {}
    public static RequestQuestStatePacket decode(FriendlyByteBuf buf) { return new RequestQuestStatePacket(); }

    public static void handle(RequestQuestStatePacket msg, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context ctx = supplier.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player != null) {
                var data = player.getPersistentData().getCompound("rpgquests");
                List<String> claimed = new ArrayList<>();
                for (Quest quest : QuestCatalog.ALL) {
                    if (data.getBoolean(quest.id())) claimed.add(quest.id());
                }
                QuestNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new SyncQuestStatePacket(claimed));
            }
        });
        ctx.setPacketHandled(true);
    }
}
